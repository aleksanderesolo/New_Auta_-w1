public interface CarCharacteristic {
    int getMaxSpeed();
    String getCarName();
}

public class CarSpeed {

    CarCharacteristic strategy;

    public void getCharacteristic(CarCharacteristic s){
        strategy = s;
    }

    public int getMaxSpeed(){
        return strategy.getMaxSpeed();
    }

    public void showCarName(){
        System.out.println(strategy.getCarName());
    }
}

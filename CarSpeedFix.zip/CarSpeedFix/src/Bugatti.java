public class Bugatti implements CarCharacteristic {
    @Override
    public int getMaxSpeed(){
        return 666;
    }
    public String getCarName(){
        return "Bugatti";
    }
}

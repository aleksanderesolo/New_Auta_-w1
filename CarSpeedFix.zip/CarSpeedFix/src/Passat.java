public class Passat implements CarCharacteristic {
    @Override
    public int getMaxSpeed(){
        return 250;
    }
    public String getCarName(){
        return "Passat";
    }
}

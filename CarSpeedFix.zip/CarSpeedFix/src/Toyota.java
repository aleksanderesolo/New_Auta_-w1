public class Toyota implements CarCharacteristic {
    @Override
    public int getMaxSpeed(){
        return 195;
    }
    public String getCarName(){
        return "Toyota";
    }
}
